# Succubus C2

![Succubus IMG](https://repository-images.githubusercontent.com/399815613/4fd6f7f4-9b4d-4885-a1d2-d2ef65398471)

1836 Lines of code and counting

Non profit c2 for all you wanting something to 
get off of the ground and start your projects.
Don't annoy or complain to others that they are
using a free c2. Why should anyone pay for 
something that's free. you just look like an 
idiot. :)

## Setup

- first step - mysql

  *need to setup mysql?* Go Here: https://dev.mysql.com/doc/mysql-installation-excerpt/5.7/en/
  
  > You may need to allow localhost to connect if you do not allow remote connections here is a command that should allow you to whitelist yourself 
  > 
  > `$ mysql -u USERNAME -pSECRET_PASSWORD mysql -e "grant ALL on *.* to USERNAME@'localhost' IDENTIFIED by 'SECRET_PASSWORD';"`

  `$ mysql -u USERNAME -p SECRET_PASSWORD succubus < doodump.sql`
  *that's all there is too it folks*

- second step - customize!
  go ahead you're already good to go!

*original made in a week flat*
