<<$clear>> clear screen 

----------------------------------------

<<$os>> Server OS
<<$arch>> Server Cpu arch "x86" the binary is compiled for x86 already

----------------------------------------

<<$username>> username for session
<<$concurrents>> allowed concurrent attacks for session
<<$timelimit>> allowed max attack time for session
<<$cooldown>> cooldown between attacks for session
<<$expiry>> expiry in days for session
<<$remoteaddress>> connected address for session
<<$remoteclient>> SSH client for session

----------------------------------------

<<$ongoing>> ongoing attacks for session
<<$onlineusers>> open sessions for server
<<$allgoing>> all running attacks for server
<<$allattacks>> total attacks for server "mysql"

----------------------------------------

<<sleep(Int)>> sleep for int

-----------------------------------------

<<$spinner>> spinner for title only
